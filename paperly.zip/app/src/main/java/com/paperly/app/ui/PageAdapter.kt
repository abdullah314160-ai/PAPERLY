package com.paperly.app.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.paperly.app.model.DocState
import com.paperly.app.model.ToolState

class PageAdapter(
    private val renderer: PdfRenderer,
    private val doc: DocState,
    private val tools: ToolState,
    private val widthPx: Int,
    private val onChanged: () -> Unit,
    private val onNote: (Int, Float, Float) -> Unit,
) : RecyclerView.Adapter<PageAdapter.Holder>() {

    class Holder(
        val image: ImageView,
        val overlay: AnnotationView,
        frame: FrameLayout,
    ) : RecyclerView.ViewHolder(frame)

    override fun getItemCount(): Int = renderer.pageCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val ctx = parent.context
        val image = ImageView(ctx).apply { adjustViewBounds = true }
        val overlay = AnnotationView(ctx)
        val frame = FrameLayout(ctx).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            )
            addView(
                image,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addView(
                overlay,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                ),
            )
        }
        return Holder(image, overlay, frame)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        renderer.openPage(position).use { page ->
            val h = (page.height * widthPx / page.width.toFloat()).toInt()
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            holder.image.setImageBitmap(bmp)
        }
        holder.overlay.bind(position + 1, doc, tools, onChanged, onNote)
    }
}

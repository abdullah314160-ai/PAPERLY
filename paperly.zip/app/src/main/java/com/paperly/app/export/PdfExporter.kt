package com.paperly.app.export

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import com.paperly.app.model.DocState
import com.paperly.app.render.AnnotationDrawer
import java.io.File

/** Writes a new PDF: each page is rendered, then annotations are painted on top (flattened). */
object PdfExporter {
    private const val SCALE = 2

    fun export(renderer: PdfRenderer, doc: DocState, out: File) {
        val pdf = PdfDocument()
        try {
            for (i in 0 until renderer.pageCount) {
                renderer.openPage(i).use { page ->
                    val pw = page.width
                    val ph = page.height
                    val bmp = Bitmap.createBitmap(pw * SCALE, ph * SCALE, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)

                    val info = PdfDocument.PageInfo.Builder(pw, ph, i + 1).create()
                    val pdfPage = pdf.startPage(info)
                    val c = pdfPage.canvas
                    c.drawBitmap(bmp, null, RectF(0f, 0f, pw.toFloat(), ph.toFloat()), null)
                    AnnotationDrawer.draw(c, pw.toFloat(), ph.toFloat(), doc.pages[i + 1].orEmpty())
                    pdf.finishPage(pdfPage)
                    bmp.recycle()
                }
            }
            out.outputStream().use { pdf.writeTo(it) }
        } finally {
            pdf.close()
        }
    }
}

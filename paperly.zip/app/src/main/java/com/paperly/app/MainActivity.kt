package com.paperly.app

import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.paperly.app.export.PdfExporter
import com.paperly.app.model.Annotation
import com.paperly.app.model.DocState
import com.paperly.app.model.Pt
import com.paperly.app.model.Tool
import com.paperly.app.model.ToolState
import com.paperly.app.ui.PageAdapter
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var toolRow: LinearLayout
    private lateinit var colorRow: LinearLayout
    private lateinit var widthBar: SeekBar

    private val tools = ToolState()
    private var doc = DocState()
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var docName = "document"
    private val toolButtons = LinkedHashMap<Tool, MaterialButton>()

    private val openLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) openPdf(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        recycler = findViewById(R.id.pages)
        recycler.layoutManager = LinearLayoutManager(this)
        toolRow = findViewById(R.id.toolRow)
        colorRow = findViewById(R.id.colorRow)
        widthBar = findViewById(R.id.widthBar)

        buildToolButtons()
        buildColorDots()
        widthBar.progress = 2
        widthBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                tools.width = 1f + progress
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        updateToolButtons()
    }

    private fun buildToolButtons() {
        val items = listOf(
            Tool.PAN to "Pan",
            Tool.HIGHLIGHT to "Highlight",
            Tool.UNDERLINE to "Underline",
            Tool.STRIKE to "Strike",
            Tool.RECT to "Box",
            Tool.OVAL to "Circle",
            Tool.LINE to "Line",
            Tool.ARROW to "Arrow",
            Tool.INK to "Draw",
            Tool.NOTE to "Note",
        )
        for ((tool, label) in items) {
            val b = MaterialButton(this).apply {
                text = label
                setOnClickListener {
                    tools.tool = tool
                    updateToolButtons()
                }
            }
            toolRow.addView(b)
            toolButtons[tool] = b
        }
    }

    private fun updateToolButtons() {
        for ((tool, b) in toolButtons) {
            b.alpha = if (tool == tools.tool) 1f else 0.45f
        }
    }

    private fun buildColorDots() {
        val colors = intArrayOf(
            0xFFFFEB3B.toInt(), // yellow
            0xFFE53935.toInt(), // red
            0xFF43A047.toInt(), // green
            0xFF1E88E5.toInt(), // blue
            0xFFFB8C00.toInt(), // orange
            0xFF8E24AA.toInt(), // purple
            0xFF000000.toInt(), // black
        )
        for (c in colors) {
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                }
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply {
                    setMargins(dp(6), 0, dp(6), 0)
                }
                setOnClickListener { tools.color = c }
            }
            colorRow.addView(dot)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun openPdf(uri: Uri) {
        closeRenderer()
        val fd = contentResolver.openFileDescriptor(uri, "r") ?: return
        pfd = fd
        val r = PdfRenderer(fd)
        renderer = r
        docName = queryName(uri)
        doc = DocState()
        recycler.adapter = PageAdapter(
            renderer = r,
            doc = doc,
            tools = tools,
            widthPx = resources.displayMetrics.widthPixels,
            onChanged = { invalidateOptionsMenu() },
            onNote = ::onNote,
        )
        title = docName
        invalidateOptionsMenu()
    }

    private fun queryName(uri: Uri): String {
        val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
        }
        return name?.removeSuffix(".pdf") ?: "document"
    }

    private fun onNote(page: Int, nx: Float, ny: Float) {
        val input = EditText(this).apply {
            minLines = 2
            hint = "Note text"
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.note_title)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) {
                    doc.add(
                        page,
                        Annotation(Tool.NOTE, tools.color, tools.width, mutableListOf(Pt(nx, ny)), text),
                    )
                    recycler.adapter?.notifyItemChanged(page - 1)
                    invalidateOptionsMenu()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun refreshAll() {
        recycler.adapter?.notifyDataSetChanged()
        invalidateOptionsMenu()
    }

    private fun save() {
        val r = renderer ?: return
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
        dir.mkdirs()
        val out = File(dir, "${docName}_paperly.pdf")
        try {
            PdfExporter.export(r, doc, out)
            Toast.makeText(this, "Saved: ${out.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_undo)?.isEnabled = doc.canUndo
        menu.findItem(R.id.action_redo)?.isEnabled = doc.canRedo
        menu.findItem(R.id.action_save)?.isEnabled = renderer != null
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_open -> {
            openLauncher.launch(arrayOf("application/pdf"))
            true
        }
        R.id.action_undo -> {
            doc.undo()
            refreshAll()
            true
        }
        R.id.action_redo -> {
            doc.redo()
            refreshAll()
            true
        }
        R.id.action_save -> {
            save()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    private fun closeRenderer() {
        renderer?.close()
        pfd?.close()
        renderer = null
        pfd = null
    }

    override fun onDestroy() {
        closeRenderer()
        super.onDestroy()
    }
}

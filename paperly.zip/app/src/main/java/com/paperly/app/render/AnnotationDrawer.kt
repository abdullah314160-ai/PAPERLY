package com.paperly.app.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.text.StaticLayout
import android.text.TextPaint
import com.paperly.app.model.Annotation
import com.paperly.app.model.Tool
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Draws annotations on screen and in the exported PDF with the same code. */
object AnnotationDrawer {

    fun draw(canvas: Canvas, w: Float, h: Float, items: List<Annotation>) {
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val s = w / 800f // stroke scale relative to page width

        for (a in items) {
            if (a.points.isEmpty()) continue
            val p0 = a.points.first()
            val p1 = a.points.last()
            val x0 = p0.x * w
            val y0 = p0.y * h
            val x1 = p1.x * w
            val y1 = p1.y * h
            val l = min(x0, x1)
            val r = max(x0, x1)
            val t = min(y0, y1)
            val b = max(y0, y1)
            val mid = (t + b) / 2f

            stroke.color = a.color
            stroke.strokeWidth = a.width * s

            when (a.tool) {
                Tool.HIGHLIGHT -> {
                    fill.color = Color.argb(90, Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                    canvas.drawRect(l, t, r, b, fill)
                }
                Tool.UNDERLINE -> canvas.drawLine(l, b, r, b, stroke)
                Tool.STRIKE -> canvas.drawLine(l, mid, r, mid, stroke)
                Tool.RECT -> canvas.drawRect(l, t, r, b, stroke)
                Tool.OVAL -> canvas.drawOval(l, t, r, b, stroke)
                Tool.LINE -> canvas.drawLine(x0, y0, x1, y1, stroke)
                Tool.ARROW -> {
                    canvas.drawLine(x0, y0, x1, y1, stroke)
                    arrowHead(canvas, x0, y0, x1, y1, stroke, s)
                }
                Tool.INK -> {
                    val path = Path()
                    path.moveTo(x0, y0)
                    for (p in a.points.drop(1)) path.lineTo(p.x * w, p.y * h)
                    canvas.drawPath(path, stroke)
                }
                Tool.NOTE -> drawNote(canvas, a, x0, y0, s, fill)
                Tool.PAN -> Unit
            }
        }
    }

    private fun arrowHead(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, p: Paint, s: Float) {
        val ang = atan2(y1 - y0, x1 - x0)
        val len = 14f * s
        for (d in doubleArrayOf(-0.45, 0.45)) {
            c.drawLine(
                x1,
                y1,
                x1 - (len * cos(ang + d)).toFloat(),
                y1 - (len * sin(ang + d)).toFloat(),
                p,
            )
        }
    }

    private fun drawNote(c: Canvas, a: Annotation, x: Float, y: Float, s: Float, fill: Paint) {
        val boxW = 150f * s
        val boxH = 70f * s
        fill.color = a.color
        c.drawRoundRect(x, y, x + boxW, y + boxH, 8f * s, 8f * s, fill)

        val text = a.text.orEmpty()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 14f * s
        }
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, tp, max(1, (boxW - 12f * s).toInt()))
            .setMaxLines(4)
            .build()
        c.save()
        c.translate(x + 6f * s, y + 6f * s)
        layout.draw(c)
        c.restore()
    }
}

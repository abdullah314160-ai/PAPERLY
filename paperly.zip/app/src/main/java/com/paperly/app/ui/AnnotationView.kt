package com.paperly.app.ui

import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View
import com.paperly.app.model.Annotation
import com.paperly.app.model.DocState
import com.paperly.app.model.Pt
import com.paperly.app.model.Tool
import com.paperly.app.model.ToolState
import com.paperly.app.render.AnnotationDrawer

/** Transparent layer on top of one page: draws annotations and receives drawing touches. */
class AnnotationView(context: Context) : View(context) {

    private var page = 0
    private var docState: DocState? = null
    private var tools: ToolState? = null
    private var onChanged: () -> Unit = {}
    private var onNote: (Int, Float, Float) -> Unit = { _, _, _ -> }
    private var draft: Annotation? = null

    fun bind(
        page: Int,
        doc: DocState,
        tools: ToolState,
        onChanged: () -> Unit,
        onNote: (Int, Float, Float) -> Unit,
    ) {
        this.page = page
        this.docState = doc
        this.tools = tools
        this.onChanged = onChanged
        this.onNote = onNote
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val doc = docState ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        AnnotationDrawer.draw(canvas, w, h, doc.pages[page].orEmpty())
        draft?.let { AnnotationDrawer.draw(canvas, w, h, listOf(it)) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val t = tools ?: return false
        val doc = docState ?: return false
        if (t.tool == Tool.PAN || width == 0 || height == 0) return false

        val nx = (e.x / width).coerceIn(0f, 1f)
        val ny = (e.y / height).coerceIn(0f, 1f)

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                draft = when (t.tool) {
                    Tool.NOTE -> null
                    Tool.INK -> Annotation(t.tool, t.color, t.width, mutableListOf(Pt(nx, ny)))
                    else -> Annotation(t.tool, t.color, t.width, mutableListOf(Pt(nx, ny), Pt(nx, ny)))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val d = draft ?: return true
                if (d.tool == Tool.INK) d.points.add(Pt(nx, ny)) else d.points[1] = Pt(nx, ny)
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (t.tool == Tool.NOTE) {
                    onNote(page, nx, ny)
                } else {
                    draft?.takeIf { isMeaningful(it) }?.let {
                        doc.add(page, it)
                        onChanged()
                    }
                }
                draft = null
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                draft = null
            }
            else -> return false
        }
        invalidate()
        return true
    }

    private fun isMeaningful(a: Annotation): Boolean =
        if (a.tool == Tool.INK) a.points.size >= 2
        else a.points.size == 2 && (a.points[0].x != a.points[1].x || a.points[0].y != a.points[1].y)
}

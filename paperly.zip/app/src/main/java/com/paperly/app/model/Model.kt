package com.paperly.app.model

enum class Tool { PAN, HIGHLIGHT, UNDERLINE, STRIKE, RECT, OVAL, LINE, ARROW, INK, NOTE }

/** Normalized point (0..1) relative to the page size. */
data class Pt(val x: Float, val y: Float)

class Annotation(
    val tool: Tool,
    val color: Int,
    val width: Float,
    val points: MutableList<Pt>,
    val text: String? = null,
)

class ToolState {
    var tool: Tool = Tool.HIGHLIGHT
    var color: Int = 0xFFFFEB3B.toInt()
    var width: Float = 3f
}

/** Annotations per page (1-based) with undo/redo. Pure Kotlin, so it is unit-testable. */
class DocState {
    val pages = HashMap<Int, MutableList<Annotation>>()
    private val undoStack = ArrayDeque<Map<Int, List<Annotation>>>()
    private val redoStack = ArrayDeque<Map<Int, List<Annotation>>>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    private fun copy(): Map<Int, List<Annotation>> = pages.mapValues { it.value.toList() }

    private fun restore(state: Map<Int, List<Annotation>>) {
        pages.clear()
        state.forEach { (k, v) -> pages[k] = v.toMutableList() }
    }

    fun snapshot() {
        undoStack.addLast(copy())
        redoStack.clear()
    }

    fun add(page: Int, annotation: Annotation) {
        snapshot()
        pages.getOrPut(page) { mutableListOf() }.add(annotation)
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(copy())
        restore(undoStack.removeLast())
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(copy())
        restore(redoStack.removeLast())
    }
}

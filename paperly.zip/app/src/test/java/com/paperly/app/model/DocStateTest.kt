package com.paperly.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DocStateTest {

    private fun rect() = Annotation(Tool.RECT, 0, 3f, mutableListOf(Pt(0f, 0f), Pt(1f, 1f)))

    @Test
    fun undoAndRedoRestoreAnnotations() {
        val doc = DocState()
        doc.add(1, rect())
        assertEquals(1, doc.pages[1]!!.size)

        doc.undo()
        assertEquals(0, doc.pages[1]?.size ?: 0)
        assertTrue(doc.canRedo)

        doc.redo()
        assertEquals(1, doc.pages[1]!!.size)
    }

    @Test
    fun newActionClearsRedo() {
        val doc = DocState()
        doc.add(1, rect())
        doc.undo()
        doc.add(2, rect())
        assertFalse(doc.canRedo)
    }
}

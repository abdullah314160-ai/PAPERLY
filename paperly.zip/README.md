# Paperly

Native Android PDF reader and annotator (Kotlin, Android PdfRenderer).

## GitHub-এ চালানো
1. এই zip extract করে repository-র root-এ সব ফাইল রাখুন (settings.gradle.kts root-এ থাকতে হবে)।
2. `.github/workflows/` ফোল্ডারে তোমার workflow yml রাখুন।
3. Push করুন। Actions → "Build Paperly APK" → Artifacts থেকে `Paperly-Android-APK` download করুন।

## ফিচার
- PDF খোলা ও পড়া (সব page scroll করে)
- Highlight, underline, strikeout (৭ রঙ)
- Box, circle, line, arrow
- Draw (freehand)
- Note (text)
- Undo / Redo
- Save: annotation সহ নতুন PDF, app-এর Documents folder-এ

## সীমাবদ্ধতা
- Pinch-zoom এখনো নেই
- Save করা PDF flattened: annotation আর edit করা যায় না
- Existing PDF-এর text edit, OCR, merge/split এখনো নেই
